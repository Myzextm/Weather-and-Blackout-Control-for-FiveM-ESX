fx_version 'cerulean'
game 'gta5'

author 'Myzex'
description 'Weather & Blackout Script for ESX'
version '1.0.0'

shared_script '@es_extended/imports.lua'

client_script 'client.lua'
server_script 'server.lua'
