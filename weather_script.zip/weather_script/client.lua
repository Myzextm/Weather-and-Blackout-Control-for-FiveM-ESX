local currentWeather = "CLEAR"
local blackout = false

RegisterNetEvent("weather:applyWeather")
AddEventHandler("weather:applyWeather", function(weatherType)
    currentWeather = weatherType
    SetWeatherTypeOvertimePersist(weatherType, 1.0)
    SetWeatherTypeNowPersist(weatherType)
    SetWeatherTypeNow(weatherType)
    SetOverrideWeather(weatherType)
end)

RegisterNetEvent("weather:setTime")
AddEventHandler("weather:setTime", function(hour, minute)
    NetworkOverrideClockTime(hour, minute, 0)
end)

RegisterNetEvent("weather:setBlackout")
AddEventHandler("weather:setBlackout", function(state)
    blackout = state
    SetBlackout(blackout)
end)

CreateThread(function()
    -- Chat command suggestion
    TriggerEvent('chat:addSuggestion', '/weather', 'Change the weather and time', {
        { name = "weatherType", help = "extrasunny, clear, neutral, smog, foggy, overcast, clouds, clearing, rain, thunder, snow, blizzard, snowlight, xmas, halloween" },
        { name = "time", help = "Optional: day or night" }
    })

    TriggerEvent('chat:addSuggestion', '/blackout', 'Toggle global blackout (power off/on)', {
        { name = "on/off", help = "Enable or disable blackout" }
    })
end)
