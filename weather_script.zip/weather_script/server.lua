-- Check if ESX is loaded
local ESX = exports['es_extended']:getSharedObject()

-- Weather Command
RegisterCommand("weather", function(source, args)
    -- Check if the player is an admin
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or xPlayer.getGroup() ~= "admin" then
        TriggerClientEvent("chat:addMessage", source, {
            args = { "[Weather]", "❌ You do not have permission." }
        })
        return
    end

    -- List of available weather types
    local validWeather = {
        extrasunny = "EXTRASUNNY",
        clear = "CLEAR",
        neutral = "NEUTRAL",
        smog = "SMOG",
        foggy = "FOGGY",
        overcast = "OVERCAST",
        clouds = "CLOUDS",
        clearing = "CLEARING",
        rain = "RAIN",
        thunder = "THUNDER",
        snow = "SNOW",
        blizzard = "BLIZZARD",
        snowlight = "SNOWLIGHT",
        xmas = "XMAS",
        halloween = "HALLOWEEN"
    }

    -- Player's input (weather type and time)
    local weatherInput = string.lower(args[1] or "")
    local timeInput = string.lower(args[2] or "")

    -- If no weather type is given, show available options
    if weatherInput == "" then
        local keys = {}
        for k in pairs(validWeather) do table.insert(keys, k) end
        table.sort(keys)
        TriggerClientEvent("chat:addMessage", source, {
            args = {
                "[Weather]",
                "🌦️ Available weather types: " .. table.concat(keys, ", ")
            }
        })
        TriggerClientEvent("chat:addMessage", source, {
            args = {
                "[Weather]",
                "📘 Usage: /weather [type] [day|night]"
            }
        })
        return
    end

    -- Check if the weather type is valid
    local weather = validWeather[weatherInput]
    if not weather then
        TriggerClientEvent("chat:addMessage", source, {
            args = {
                "[Weather]",
                "❌ Invalid weather type. Use /weather to see valid types."
            }
        })
        return
    end

    -- Apply the weather
    TriggerClientEvent("weather:applyWeather", -1, weather)

    -- Set time (day or night)
    if timeInput == "day" then
        TriggerClientEvent("weather:setTime", -1, 12, 0) -- 12:00 PM (Day)
    elseif timeInput == "night" then
        TriggerClientEvent("weather:setTime", -1, 0, 0) -- 12:00 AM (Night)
    end

    -- Send confirmation to all players
    TriggerClientEvent("chat:addMessage", -1, {
        args = {
            "[Weather]",
            "✅ Weather changed to " .. weatherInput .. (timeInput ~= "" and (" | Time: " .. timeInput) or "")
        }
    })
end, false)

-- Blackout Command
RegisterCommand("blackout", function(source, args)
    -- Check if the player is an admin
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or xPlayer.getGroup() ~= "admin" then
        TriggerClientEvent("chat:addMessage", source, {
            args = { "[Blackout]", "❌ You do not have permission." }
        })
        return
    end

    -- Check the state of the blackout (on/off)
    local state = string.lower(args[1] or "")
    if state ~= "on" and state ~= "off" then
        TriggerClientEvent("chat:addMessage", source, {
            args = {
                "[Blackout]",
                "📘 Usage: /blackout [on|off]"
            }
        })
        return
    end

    -- Set the blackout state
    local isBlackout = state == "on"
    TriggerClientEvent("weather:setBlackout", -1, isBlackout)

    -- Send confirmation to all players
    TriggerClientEvent("chat:addMessage", -1, {
        args = {
            "[Blackout]",
            "💡 Blackout is now " .. (isBlackout and "ON" or "OFF")
        }
    })
end, false)

-- Debug: Test if the script is loaded correctly
print("The Weather and Blackout script has been successfully loaded!")
